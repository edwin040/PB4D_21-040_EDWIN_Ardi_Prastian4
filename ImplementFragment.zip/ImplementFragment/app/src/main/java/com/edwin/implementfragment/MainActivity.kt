package com.edwin.implementfragment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.fragment.app.FragmentManager

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // add id fragment to object
        val fristFragment = FristFragment()
        val secondFragment = SecondFragment()
        // action frist
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fragimp, fristFragment)
            commit()
        }
        //react button click
        val btnFristFragment = findViewById<Button>(R.id.button2)
        //swicth view
        btnFristFragment.setOnClickListener{
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.fragimp, fristFragment)
                commit()
            }
        }

        val btnSecondFragment = findViewById<Button>(R.id.button3)

        btnSecondFragment.setOnClickListener{
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.fragimp, secondFragment)
                commit()
            }
        }
    }
}